using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Channels;
using System.Threading.Tasks;
using Grpc.Core;
using Microsoft.Extensions.Logging;

namespace Grpc.msa.inventory
{
    public class InventoryService : Inventory.InventoryBase
    {
        private readonly ILogger<InventoryService> _logger;
        public InventoryService(ILogger<InventoryService> logger)
        {
            _logger = logger;
        }

        public async override Task ConfirmOrder(IAsyncStreamReader<OrderInfo> requestStream, IServerStreamWriter<ConfirmOrderResponse> responseStream, ServerCallContext context)
        {
            var rng = new Random();

            while (await requestStream.MoveNext(CancellationToken.None))
            {
                int status = rng.Next(1, 3);
                await responseStream.WriteAsync(new ConfirmOrderResponse()
                {
                    OrderID = requestStream.Current.Id,
                    Status = status,
                    Message = status == 1 ? "OK" : "NOK",
                });
            }
        }
    }
}
