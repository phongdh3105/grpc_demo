﻿using Google.Protobuf.WellKnownTypes;
using Grpc.Core;
using Grpc.Net.Client;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using static Grpc.msa.customers.Order;
using static Grpc.msa.inventory.Inventory;

namespace Grpc.msa.customers.Services
{
    public class OrderService : OrderBase
    {
        private readonly ILogger<OrderService> _logger;
        private static List<OrderInfo> _orders = new List<OrderInfo>();
        private static List<OrderInfo> _orderConfirmed = new List<OrderInfo>();

        public OrderService(ILogger<OrderService> logger)
        {
            _logger = logger;
        }

        public override Task<OrderBasicResult> CreateOrder(OrderInfo request, ServerCallContext context)
        {
            request.Id = Guid.NewGuid().ToString("N");
            request.Status = 0;

            _orders.Add(request);

            return Task.FromResult(new OrderBasicResult()
            {
                Code = 1,
                Message = $"Successful: {request.Id}"
            });
        }

        public override Task<OrderResponse> GetAllOrder(Empty request, ServerCallContext context)
        {
            var result = new OrderResponse();
            result.Orders.AddRange(_orders);

            return Task.FromResult(result);
        }

        public override Task<OrderResponse> GetOrderById(GetByIdRequest request, ServerCallContext context)
        {
            var result = new OrderResponse();
            result.Orders.AddRange(_orders.Where(x => x.Id.ToLower().Equals(request.Id.ToLower())));

            return Task.FromResult(result);
        }

        public async override Task<OrderBasicResult> ConfirmOrder(Empty request, ServerCallContext context)
        {
            using var channel = GrpcChannel.ForAddress("https://localhost:5005");
            var client = new InventoryClient(channel);
            using var cfOrder = client.ConfirmOrder();

            foreach (var item in _orders)
            {
                var ivOrderInfo = new inventory.OrderInfo()
                {
                    CusId = item.CusId,
                    CusName = item.CusName,
                    Id = item.Id,
                    Status = item.Status
                };
                ivOrderInfo.Items.AddRange(item.Items.Select(x => new inventory.OrderItem()
                {
                    BookId = x.BookId,
                    BookPrice = x.BookPrice,
                    BookTitle = x.BookTitle,
                }).ToList());

                await cfOrder.RequestStream.WriteAsync(ivOrderInfo);
            }

            var responseProcessing = Task.Run(async () =>
            {
                try
                {
                    await foreach (var cf in cfOrder.ResponseStream.ReadAllAsync())
                    {
                        // Console.WriteLine($"{cf.OrderID} - {cf.Message}");
                        var temp = _orders.FirstOrDefault(x => x.Id == cf.OrderID);
                        if (temp != null)
                        {
                            // client stream pubsub service
                            _orderConfirmed.Add(temp);
                        }
                    }
                }
                catch (RpcException ex) when (ex.StatusCode == StatusCode.Cancelled)
                {
                    Console.WriteLine("Stream cancelled.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error reading response: " + ex);
                }
            });

            await cfOrder.RequestStream.CompleteAsync();
            await responseProcessing;

            var pubsub = new PubSubService();
            if (_orderConfirmed.Count() == 0)
            {
                _orderConfirmed.ToList().Add(_orders.First());
            }

            //await pubsub.PublishStreamAsync(_orderConfirmed);
            foreach (var item in _orderConfirmed)
            {
                pubsub.Publish(item.Id);
            }

            var result = new OrderBasicResult()
            {
                Code = 1,
                Message = $"Successful: {string.Join(" | ", _orderConfirmed.Select(x => x.Id))}",
            };
            return await Task.FromResult(result);
        }
    }
}
