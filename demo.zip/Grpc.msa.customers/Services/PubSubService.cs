﻿using Grpc.msa.customers.Models;
using Grpc.Net.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Grpc.msa.customers.Services
{
    public class PubSubService
    {
        public void Publish(string orderId)
        {
            using var channel = GrpcChannel.ForAddress("https://localhost:5007");
            var client = new PubSub.Server.PubSub.PubSubClient(channel);
            client.Publish(new PubSub.Server.Content() { Msg = $"{orderId}" });
            channel.Dispose(); 
        }

        public async Task PublishStreamAsync(List<OrderInfo> orderConfirmed)
        {
            using var channel = GrpcChannel.ForAddress("https://localhost:5007");
            var client = new PubSub.Server.PubSub.PubSubClient(channel);
            var requestStream = client.PublishStream();
            foreach (var item in orderConfirmed)
            {
                await requestStream.RequestStream.WriteAsync(new PubSub.Server.Content() { Msg = $"{item.Id}" });
            }
            await requestStream.RequestStream.CompleteAsync();
            channel.Dispose();
        }
    }
}
