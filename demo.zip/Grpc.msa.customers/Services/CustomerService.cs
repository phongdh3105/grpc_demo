using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Google.Protobuf.WellKnownTypes;
using Grpc.Core;
using Microsoft.Extensions.Logging;

namespace Grpc.msa.customers
{
    public class CustomerService : Customer.CustomerBase
    {
        private readonly ILogger<CustomerService> _logger;
        private static List<CustomerInfo> _customers = new List<CustomerInfo>();
        public CustomerService(ILogger<CustomerService> logger)
        {
            _logger = logger;
        }

        public override Task<BasicResult> CreateCustomer(CustomerInfo request, ServerCallContext context)
        {
            request.Id = Guid.NewGuid().ToString("N");
            _customers.Add(request);

            return Task.FromResult(new BasicResult
            {
                Message = $"Success: {request.Id}",
                Code = 1
            });
        }

        public override Task<CustomersResponse> GetAllCustomer(Empty request, ServerCallContext context)
        {
            var result = new CustomersResponse();
            result.Customers.AddRange(_customers);
            return Task.FromResult(result);
        }
    }
}
