﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Threading.Tasks.Dataflow;
using Google.Protobuf.WellKnownTypes;
using Grpc.Core;
using Microsoft.Extensions.Logging;

namespace Grpc.PubSub.Server.Services
{
    public class PubSubServices : PubSub.PubSubBase
    {
        private static BufferBlock<Event> _buffer = new BufferBlock<Event>();
        private static Dictionary<string, IServerStreamWriter<Event>> _subscriberWritersMap = new Dictionary<string, IServerStreamWriter<Event>>();
        private readonly ILogger<PubSubServices> _logger;

        public PubSubServices(ILogger<PubSubServices> logger)
        {
            _logger = logger;
        }

        public override async Task Subscribe(Subscription request, IServerStreamWriter<Event> responseStream, ServerCallContext context)
        {
            _subscriberWritersMap[request.Id] = responseStream;

            while (_subscriberWritersMap.ContainsKey(request.Id))
            {
                var @event = await _buffer.ReceiveAsync();
                foreach (var key in _subscriberWritersMap.Keys)
                {
                    var serverStreamWriter = _subscriberWritersMap[key];
                    try
                    {
                        await serverStreamWriter.WriteAsync(@event);
                    }
                    catch (Exception ex)
                    {
                        _subscriberWritersMap.Remove(key);
                    }
                }
            }
        }

        public override Task<Unsubscription> Unsubscribe(Subscription request, ServerCallContext context)
        {
            _subscriberWritersMap.Remove(request.Id);
            return Task.FromResult(new Unsubscription() { Id = request.Id });
        }

        public override Task<Empty> Publish(Content request, ServerCallContext context)
        {
            Console.WriteLine(request.Msg);
            _buffer.Post(new Event() { Value = request.Msg });
            return Task.FromResult(new Empty());
        }

        public override async Task<Empty> PublishStream(IAsyncStreamReader<Content> requestStream, ServerCallContext context)
        {
            await foreach (var item in requestStream.ReadAllAsync())
            {
                Console.WriteLine(requestStream.Current.Msg);
                _buffer.Post(new Event() { Value = requestStream.Current.Msg });
            }
            return await Task.FromResult(new Empty());
        }
    }
}
