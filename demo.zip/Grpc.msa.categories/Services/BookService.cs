﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Google.Protobuf.WellKnownTypes;
using Grpc.Core;
using Microsoft.Extensions.Logging;
using static Grpc.msa.categories.Books;

namespace Grpc.msa.categories.Services
{
    public class BookService : BooksBase
    {
        private readonly ILogger<BookService> _logger;
        private static List<BookInfo> _books;
        public BookService(ILogger<BookService> logger)
        {
            _logger = logger;
            _books = new List<BookInfo>()
            {
                new BookInfo()
                {
                    Id = 1,
                    Title = "Book 1",
                    Author = "Author 1",
                    Price = 1000
                },
                new BookInfo()
                {
                    Id = 2,
                    Title = "Book 2",
                    Author = "Author 1",
                    Price = 2000
                },
                new BookInfo()
                {
                    Id = 3,
                    Title = "Book 3",
                    Author = "Author 2",
                    Price = 2000
                },
            };
        }

        public override Task<BooksResponse> GetAllBook(Empty request, ServerCallContext context)
        {
            var result = new BooksResponse();
            result.Books.AddRange(_books);
            return Task.FromResult(result);
        }

        public async override Task GetAllBookStream(Empty request, IServerStreamWriter<BookInfo> responseStream, ServerCallContext context)
        {
            foreach (var item in _books)
            {
                await responseStream.WriteAsync(item);
            }
        }

        public override Task<BooksResponse> GetBookByAuthor(GetByAuthorRequest request, ServerCallContext context)
        {
            var books = _books.Where(x => x.Author.ToLower().Equals(request.Author.ToLower()));
            var result = new BooksResponse();
            result.Books.AddRange(books);
            return Task.FromResult(result);
        }
    }
}
