﻿using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grpc.msa.categories
{
    public class Middlewares
    {
        private readonly RequestDelegate _next;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="next"></param>
        public Middlewares(RequestDelegate next)
        {
            this._next = next;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="httpContext"></param>
        /// <returns></returns>
        public async Task Invoke(HttpContext httpContext)
        {
            bool result = false;
            try
            {
                var request = httpContext.Request;
                // var a = ReadRequestBody(request);
                result = true;
                await _next(httpContext);
            }
            catch(Exception ex)
            {
                return;
            }
            finally
            {
                if (!result)
                {
                    var response = httpContext.Response;
                    response.ContentType = "application/json";
                    response.StatusCode = StatusCodes.Status401Unauthorized;
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        private string ReadRequestBody(HttpRequest request)
        {
            request.EnableBuffering();
            var buffer = new byte[Convert.ToInt32(request.ContentLength)];
            request.Body.ReadAsync(buffer, 0, buffer.Length);
            var bodyAsText = Encoding.UTF8.GetString(buffer);
            request.Body.Seek(0, SeekOrigin.Begin);

            var temp = JsonConvert.DeserializeObject(bodyAsText);
            bodyAsText = JsonConvert.SerializeObject(temp);
            return bodyAsText;
        }
    }
}
