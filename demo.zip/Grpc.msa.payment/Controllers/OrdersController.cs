﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Google.Protobuf.WellKnownTypes;
using Grpc.Net.Client;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Grpc.msa.aggregate.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class OrdersController : ControllerBase
    {
        private static readonly string _msaOrderUrl = "https://localhost:5001";

        [HttpPost]
        public async Task<customers.OrderBasicResult> CreateOrder([FromBody]customers.OrderInfo order)
        {
            using var channel = GrpcChannel.ForAddress(_msaOrderUrl);
            var client = new customers.Order.OrderClient(channel);
            var result = await client.CreateOrderAsync(order);
            return await Task.FromResult(result);
        }

        [HttpGet]
        public async Task<customers.OrderResponse> GetAllOrder()
        {
            using var channel = GrpcChannel.ForAddress(_msaOrderUrl);
            var client = new customers.Order.OrderClient(channel);
            var result = await client.GetAllOrderAsync(new Empty());
            return await Task.FromResult(result);
        }


        [HttpGet("{orderId}", Name = "GetOrderById")]
        public async Task<customers.OrderResponse> GetOrderById(string orderId)
        {
            using var channel = GrpcChannel.ForAddress(_msaOrderUrl);
            var client = new customers.Order.OrderClient(channel);
            var result = await client.GetOrderByIdAsync(new customers.GetByIdRequest() { Id = orderId });
            return await Task.FromResult(result);
        }

        [HttpPost]
        public async Task<customers.OrderBasicResult> ConfirmOrder()
        {
            using var channel = GrpcChannel.ForAddress(_msaOrderUrl);
            var client = new customers.Order.OrderClient(channel);
            var result = await client.ConfirmOrderAsync(new Empty());
            return await Task.FromResult(result);
        }
    }
}