﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Google.Protobuf.WellKnownTypes;
using Grpc.Net.Client;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Grpc.msa.aggregate.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class CategoriesController : ControllerBase
    {
        public static string _msaCategoriesUrl = "https://localhost:5012";

        [HttpGet(Name = "GetAllBook")]
        public async Task<categories.BooksResponse> GetAllBook()
        {
            using var channel = GrpcChannel.ForAddress(_msaCategoriesUrl);
            var client = new categories.Books.BooksClient(channel);
            var books = await client.GetAllBookAsync(new Empty());
            channel.Dispose();

            return await Task.FromResult(books);
        }

        [HttpGet("{author}", Name = "GetByAuthor")]
        public async Task<categories.BooksResponse> GetByAuthor(string author)
        {
            using var channel = GrpcChannel.ForAddress(_msaCategoriesUrl);
            var client = new categories.Books.BooksClient(channel);
            var books = await client.GetBookByAuthorAsync(new categories.GetByAuthorRequest()
            {
                Author = author,
            });
            channel.Dispose();

            return await Task.FromResult(books);
        }
    }
}