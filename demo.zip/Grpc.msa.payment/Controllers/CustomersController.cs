﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Google.Protobuf.WellKnownTypes;
using Grpc.Net.Client;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Grpc.msa.aggregate.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class CustomersController : ControllerBase
    {
        private static readonly string _msaCustomerUrl = "https://localhost:5001";

        [HttpPost]
        public async Task<customers.BasicResult> CreateCustomerInfo([FromBody] customers.CustomerInfo customer)
        {
            using var channel = GrpcChannel.ForAddress(_msaCustomerUrl);
            var client = new customers.Customer.CustomerClient(channel);
            var result = await client.CreateCustomerAsync(customer);
            return await Task.FromResult(result);
        }

        [HttpGet(Name = "GetAllCustomer")]
        public async Task<customers.CustomersResponse> GetAllCustomer()
        {
            using var channel = GrpcChannel.ForAddress(_msaCustomerUrl);
            var client = new customers.Customer.CustomerClient(channel);
            var result = await client.GetAllCustomerAsync(new Empty());
            return await Task.FromResult(result);
        }
    }
}