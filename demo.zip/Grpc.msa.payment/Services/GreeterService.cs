using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Grpc.Core;
using Microsoft.Extensions.Logging;

namespace Grpc.msa.aggregate
{
    public class GreeterService : Greeter.GreeterBase
    {
        private readonly ILogger<GreeterService> _logger;
        public GreeterService(ILogger<GreeterService> logger)
        {
            _logger = logger;
        }

        public override Task<HelloReply> SayHello(HelloRequest request, ServerCallContext context)
        {
            return Task.FromResult(new HelloReply
            {
                Message = "Hello " + request.Name
            });
        }

        public async override Task<HelloReply> SayHelloClientStream(IAsyncStreamReader<HelloRequest> requestStream, ServerCallContext context)
        {
            int count = 0;
            await foreach (var item in requestStream.ReadAllAsync())
            {
                Console.WriteLine(item.Name);
                count++;
            }
            return await Task.FromResult(new HelloReply
            {
                Message = $"End stream {count}"
            }); ;
        }

        public async override Task SayHelloDuplexStream(IAsyncStreamReader<HelloRequest> requestStream, IServerStreamWriter<HelloReply> responseStream, ServerCallContext context)
        {
            int count = 0;
            _ = Task.Run(async () =>
            {
                int count2 = 5;
                for (int i = 1; i <= count2; i++)
                {
                    await responseStream.WriteAsync(new HelloReply
                    {
                        Message = $"Message reply {i}",
                    });
                }
            });

            await foreach (var item in requestStream.ReadAllAsync())
            {
                Console.WriteLine(item.Name);
                count++;
            }
        }

        public async override Task SayHelloServerStream(HelloRequest request, IServerStreamWriter<HelloReply> responseStream, ServerCallContext context)
        {
            int count = 0;
            if (int.TryParse(request.Name, out count))
            {
                for (int i = 1; i <= count; i++)
                {
                    await responseStream.WriteAsync(new HelloReply
                    {
                        Message = $"Message reply {i}",
                    });
                }
            }
        }
    }
}
