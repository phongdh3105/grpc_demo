﻿using Grpc.Net.Client;
using System;
using System.Collections.Generic;
using System.Text;

namespace Grpc.PubSub.Publisher.Services
{
    public class PubSubServices
    {
        public void Publish()
        {
            using var channel = GrpcChannel.ForAddress("https://localhost:5001");
            var client = new Server.PubSub.PubSubClient(channel);

            Console.WriteLine("Insert event. 'q' to quit.");
            string input;
            while ((input = Console.ReadLine()) != "q")
            {
                client.Publish(new Server.Content() { Msg = input });
            }

            Console.WriteLine("Press a key to exit");
            Console.ReadKey();
        }
    }
}
