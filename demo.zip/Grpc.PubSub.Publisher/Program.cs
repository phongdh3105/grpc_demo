﻿using Grpc.PubSub.Publisher.Services;
using System;

namespace Grpc.PubSub.Publisher
{
    class Program
    {
        static void Main(string[] args)
        {
            new PubSubServices().Publish();
        }
    }
}
