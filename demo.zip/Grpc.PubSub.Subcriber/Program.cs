﻿using Grpc.Core;
using Grpc.Net.Client;
using Grpc.PubSub.Subcriber.Services;
using System;
using System.Threading.Tasks;

namespace Grpc.PubSub.Subcriber
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Press any to subscribe:");
            var key = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(key)){

                var channel = GrpcChannel.ForAddress("https://localhost:5007");
                var subscriber = new SubciberServices(new Server.PubSub.PubSubClient(channel));

                Task.Run(async () =>
                {
                    await subscriber.Subscribe();
                }).GetAwaiter();

                Console.WriteLine("Hit key to unsubscribe");
                Console.ReadLine();
                subscriber.Unsubscribe();
                Console.WriteLine("Unsubscribed...");
                Console.WriteLine("Hit key to exit...");
                Console.ReadLine();
            }
        }
    }
}
