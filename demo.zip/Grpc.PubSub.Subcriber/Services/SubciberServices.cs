﻿using Grpc.Core;
using Grpc.PubSub.Server;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Grpc.PubSub.Subcriber.Services
{
    public class SubciberServices
    {
        private readonly Server.PubSub.PubSubClient _pubSubClient;
        private Subscription _subscription;

        public SubciberServices(Server.PubSub.PubSubClient pubSubClient)
        {
            _pubSubClient = pubSubClient;
        }

        public async Task Subscribe()
        {
            _subscription = new Subscription() { Id = Guid.NewGuid().ToString() };
            using (var call = _pubSubClient.Subscribe(_subscription))
            {
                //Receive
                var responseReaderTask = Task.Run(async () =>
                {
                    while (await call.ResponseStream.MoveNext())
                    {
                        Console.WriteLine("Event received: " + call.ResponseStream.Current);
                    }
                });

                await responseReaderTask;
            }
        }

        public void Unsubscribe()
        {
            _pubSubClient.Unsubscribe(_subscription);
        }
    }
}
